import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(encrp("Vaseem Khan"));

	}

	static HashMap<Integer, List<Integer>> encrp(String s) {

		HashMap<Integer, List<Integer>> actulList = new HashMap<>();

		char[] a = s.toCharArray();

		for (int i = 0; i <= a.length - 1; i++) {

			if (!actulList.keySet().contains((int) a[i])) {
				List<Integer> ls = new ArrayList<>();
				for (int j = 0; j <= a.length - 1; j++) {

					if (a[i] == a[j]) {
						ls.add(j);
					}

				}
				actulList.put((int) a[i], ls);
			}

		}

		return actulList;
	}

	static void decp(HashMap<Integer, List<Integer>> ac) {
		Set<Integer> acut = new HashSet<>();

		for (List<Integer> k : ac.values()) {
			acut.addAll(k);
		}

		char[] s = new char[acut.size()];

		for (int k : acut) {

			for (Map.Entry<Integer, List<Integer>> l : ac.entrySet()) {

				if (l.getValue().contains(k)) {
					s[k] = (char) (int) l.getKey();
				}

			}

		}

		for (char b : s) {
			System.out.print(b);
		}
	}

}
