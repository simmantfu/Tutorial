
public class Test2 {

	public static void main(String...strings){
		
		int a = ;
		
		char b = (char)a;
		
		System.out.println(b);
		
		
	}
	
	
}
